import Fmm from "../images/Fmm.png"
import Olam from "../images/Olam.png"
import Seed from "../images/seeds.png"
import Indorma from "../images/Indorma.png"
import Obsanjo from "../images/Obsanjo.png"
import Stallion from "../images/Stallion.png"
import Dangote from "../images/Dangote.png"
import Bua from "../images/Bua.png"
import Farmer from "../images/Farmer.png"
import Miva from "../images/Miva.png"
import Crest from "../images/Crest.png"
import Tropical from "../images/Tgi.png"




const OfficalData = [
    {
        image: Olam
    },
    {
        image: Fmm
    },
    {
        image: Seed
    },
    {
        image: Indorma
    },
    {
        image: Obsanjo
    },
    {
        image: Stallion 
    },
    {
        image:Dangote 
    },
    {
        image: Bua
    },
    {
        image: Farmer
    },
    {
        image:Miva
    },
    {
        image: Crest
    },
    {
        image: Tropical
    }
]


export default OfficalData