import { Box } from '@mui/system'
import React from 'react'
import MSB from './MSB'
// import SideBarImg from './sidebar.png'


const SideBar = () => {
    return (
        <Box sx={{backgroundColor:'white'}}>
            <MSB />
        </Box>
    )
}

export default SideBar