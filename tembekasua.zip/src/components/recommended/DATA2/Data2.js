import Roots from "../images/Cassava-roots.png"
import Corn from "../images/guinea-corn.png"
import RAMs from "../images/IMG_20210901_143335_298.png"
import Nuts from "../images/bambrara-nut.png"
import Potatos from "../images/figure-1.png"
import Turkey from "../images/Turkey-Farming.png"


const Data2 = [
    {
        name: "Cassava",
        Disprice: "₦600",
        OrigPrice: "₦800",
        image: Roots

    },
    {
        name: "Guinea corn",
        Disprice: "₦6,000",
        OrigPrice: "₦8,000",
        image: Corn

    },
    {
        name: "Ram- Fully Matured & Healthy ",
        Disprice: "₦60,00",
        OrigPrice: "₦75,000",
        image: RAMs

    },
    {
        name: "Bambara Nuts",
        Disprice: "₦700",
        OrigPrice: "₦800",
        image:Nuts

    },
    {
        name: "Sweet Potatos",
        Disprice: "₦1,500",
        OrigPrice: "₦3,000",
        image: Potatos

    },
    {
        name: "Matured Male Turkey",
        Disprice: "₦25,000",
        OrigPrice: "₦30,000 ",
        image: Turkey

    },
]
export default Data2