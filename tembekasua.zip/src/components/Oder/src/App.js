import logo from "./logo.svg";
import "./App.css";
import Oder from "./oder/Oder";
import Wallet from "./MyWallet/MyWallet";

function App() {
  return (
    <div className="App">
      <Oder />
    </div>
  );
}

export default App;
