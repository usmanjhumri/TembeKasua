import { Box, Container, FormControl, FormControlLabel, FormLabel, Grid, Radio, RadioGroup, TextField } from '@mui/material'
import React from 'react'
import BG from './bg-img.png'

const Popup = () => {
  return (
    <div>
      

<Box>
  <Container>
    <Grid container>
      
    </Grid>
  </Container>
</Box>


    </div>
  )
}

export default Popup
