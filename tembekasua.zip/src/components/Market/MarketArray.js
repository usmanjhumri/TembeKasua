import GUINEA_FOWL from './moretolove-img/Guinea Fowl.png'
import  MATURED_FEMALE_PIG  from './moretolove-img/Matured Female Pig.png'
import PURE_RED_BULL from './moretolove-img/Pure Red oil - palm kernel.png'
import DRIED_SHORT_PAPER from './moretolove-img/Dried short pepper - Clean  ....png'
import DRIED_CORN from './moretolove-img/Dried Corn - Clean and well ....png'
import SOYA_BEANS from './moretolove-img/Soya beans - Clean and well ....png'




export  const indexArray = [
    {
        title:"Vegetables",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Tubers",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Fruits",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Grains",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Protein Foods ",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Liverstock",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Oils & Solid Fats",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Fertilizer",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },
    {
        title:"Tools & Equipments",
        subtitle:"Cassava   Yam   Sweet Potatoe",  
        subtitleone: "Carrot   Cocoyam   Irish Potatoe"
    },

]





export const MoreToLove = [
    {
        name: "Guinea Fowl",
        Disprice: "₦700/rubber",
        OrigPrice: "₦10,000",
        img: GUINEA_FOWL

    },
    {
        name: "Matured Female Pig",
        Disprice: "₦70,000/basin",
        OrigPrice: "₦80,000",
        img: MATURED_FEMALE_PIG
    },
    {
        name: "Pure Red oil - palm kernel",
        Disprice: "₦1200/liter",
        OrigPrice: "₦1500",
        img: PURE_RED_BULL

    },
    {
        name: "Dried short pepper - Clean",
        Disprice: "₦250/mudu",
        OrigPrice: "₦500",
        img: DRIED_SHORT_PAPER

    },
    {
        name: "Dried Corn - Clean and well",
        Disprice: "₦650/mudu",
        OrigPrice: "₦950",
        img: DRIED_CORN
    },
    {
        name: "Soya beans - Clean and well",
        Disprice: "₦800/mudu",
        OrigPrice: "₦1,000",
        img: SOYA_BEANS

    },
]