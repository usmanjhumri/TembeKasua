import Guinea from "../Images/Guinea-fowl.png"
import Pig from "../Images/Oasdom-how-to-start-pig-farming-business-in-Nigeria.png"
import RedOil from "../Images/IMG_1453-300x400.png"
import RedPepper from "../Images/Dried-Red-Chillie-peppers.png"
import Corn from "../Images/Untitled-design-2020-12-23T104948.png"
import SoyaBean from "../Images/IMG-20210217-WA0003-e1613562224212-768x839.png"


const Data = [
    {
        name: "Guinea Fowl",
        Disprice: "₦7,000",
        OrigPrice: "₦10,000",
        image: Guinea

    },
    {
        name: "Mature Female Pig",
        Disprice: "₦70,000",
        OrigPrice: "₦80,000",
        image: Pig

    },
    {
        name: "Pure Red oil-palm  ",
        Disprice: "₦1,200",
        OrigPrice: "₦1,600",
        image: RedOil

    },
    {
        name: "Dried short pepper",
        Disprice: "₦250",
        OrigPrice: "₦ 600",
        image:RedPepper

    },
    {
        name: "Dried Corn",
        Disprice: "₦650",
        OrigPrice: "₦950",
        image: Corn

    },
    {
        name: "Soya Bean",
        Disprice: "₦800",
        OrigPrice: "₦1000",
        image: SoyaBean

    },
]
export default Data