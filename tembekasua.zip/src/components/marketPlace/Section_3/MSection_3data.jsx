import Guinea from './Guinea.png'
import Oasdom from './Oasdom.png'
import redOil from './red-oil.png'
import RedChillie from './Red-Chillie.png'
import corn from './corn.png'
import soya from './soya.png'





const MSection_3data = [
    {
        Image: Guinea,
        name: 'Guinea Fowl',
        Disprice: '₦10,000',
        OrigPrice: '₦7,000',

    },
    {
        Image: Oasdom,
        name: 'Matured Female Pig',
        Disprice: '₦80,000',
        OrigPrice: '₦70,000',

    },
    {
        Image: redOil,
        name: 'Pure Red oil - palm kernel',
        Disprice: '₦1500',
        OrigPrice: '₦1,200/litre',

    },
    {
        Image: RedChillie,
        name: 'Dried short pepper - Clean  ...',
        Disprice: '₦500',
        OrigPrice: '₦250/mudu',

    },
    {
        Image: corn,
        name: 'Dried Corn - Clean and well ...',
        Disprice: '₦950',
        OrigPrice: '₦650/mudu',

    },
    {
        Image: soya,
        name: 'Soya beans - Clean and well ...',
        Disprice: '₦1000',
        OrigPrice: '₦800/mudu',

    },
]

export default MSection_3data;