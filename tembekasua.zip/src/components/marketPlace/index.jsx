import React from 'react'
import MSection_1 from './Section_1/MSection_1'
import MSection_2 from './Section_2/MSection_2'
import MSection_3 from './Section_3/MSection_3'


const Markets = () => {
  return (
    <div>
     <MSection_1/>
     <MSection_2/>
     <MSection_3/>
      
    </div>
  )
}

export default Markets
