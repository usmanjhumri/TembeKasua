import guineacorn from './guinea-corn.png'
import Cassava from './Cassava.png'
import goat from './goat.png'
import bambrara from './bambrara.png'
import figure from './figure.png'
import Turkey from './Turkey.png'


const MSection_2data = [
    {
        Image: guineacorn,
        name: 'Guinea Corn',
        Disprice: '₦8,000',
        OrigPrice: '₦6,000/basin',

    },
    {
        Image: Cassava,
        name: 'Cassava',
        Disprice: '₦800',
        OrigPrice: '₦600/tuber',

    },
    {
        Image: goat,
        name: 'Ram - Fully Mature & Healthy',
        Disprice: '₦75,000',
        OrigPrice: '₦60,000',

    },
    {
        Image: figure,
        name: 'Sweet Potatoes',
        Disprice: '₦3,000',
        OrigPrice: '₦1,500/rubber',

    },
    {
        Image: bambrara,
        name: 'Bambara nuts',
        Disprice: '₦800',
        OrigPrice: '₦700/rubber',

    },
    {
        Image: Turkey,
        name: 'Matured Male Turkey',
        Disprice: '₦30,000',
        OrigPrice: '₦25,000',

    },
    ////////////////////////////////////////scnd//////////////////
    {
        Image: figure,
        name: 'Sweet Potatoes',
        Disprice: '₦3,000',
        OrigPrice: '₦1,500/rubber',

    },
    {
        Image: guineacorn,
        name: 'Guinea Corn',
        Disprice: '₦8,000',
        OrigPrice: '₦6,000/basin',

    },
    {
        Image: Cassava,
        name: 'Cassava',
        Disprice: '₦800',
        OrigPrice: '₦600/tuber',

    },
    {
        Image: Turkey,
        name: 'Matured Male Turkey',
        Disprice: '₦30,000',
        OrigPrice: '₦25,000',

    },
    {
        Image: bambrara,
        name: 'Bambara nuts',
        Disprice: '₦800',
        OrigPrice: '₦700/rubber',

    },
    {
        Image: goat,
        name: 'Ram - Fully Mature & Healthy',
        Disprice: '₦75,000',
        OrigPrice: '₦60,000',

    },
    //////////////////////////////////////////////////thrd///////////////////////////////////
    {
        Image: Turkey,
        name: 'Matured Male Turkey',
        Disprice: '₦30,000',
        OrigPrice: '₦25,000',

    },
    {
        Image: bambrara,
        name: 'Bambara nuts',
        Disprice: '₦800',
        OrigPrice: '₦700/rubber',

    },
    {
        Image: goat,
        name: 'Ram - Fully Mature & Healthy',
        Disprice: '₦75,000',
        OrigPrice: '₦60,000',

    },
    {
        Image: Cassava,
        name: 'Cassava',
        Disprice: '₦800',
        OrigPrice: '₦600/tuber',

    },
    {
        Image: figure,
        name: 'Sweet Potatoes',
        Disprice: '₦3,000',
        OrigPrice: '₦1,500/rubber',

    },
    {
        Image: guineacorn,
        name: 'Guinea Corn',
        Disprice: '₦8,000',
        OrigPrice: '₦6,000/basin',

    },
]

export default MSection_2data;