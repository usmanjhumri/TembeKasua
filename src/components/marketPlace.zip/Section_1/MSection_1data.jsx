import people from './carpeople.png'
import peomarketple from './people in market.png'




const Section_2Data = [
    { heading: 'Ugbema  Market ', image: peomarketple },
    { heading: 'Obagaji Market', image: people },
    { heading: 'Eve Utonkon  Market ', image: peomarketple },
    { heading: 'Okpagabi  Market ', image: people },
    { heading: 'Ugbema  Market  ', image: peomarketple },
    { heading: 'Obagaji Market', image: people },
    { heading: 'Ugbema  Market  ', image: peomarketple },
    { heading: 'Obagaji Market', image: people },

    // { image:}
]
export default Section_2Data;