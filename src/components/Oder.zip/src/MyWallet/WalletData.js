import RedArrow from './images/RedArrow.png'
import GreenArrow from "./images/GreenArrow.png"

const WalletData=[

{
    image:RedArrow,
    Date:"30 November, 2022",
    ItemName:"Name of product bought",
    StoreName:"Name of Store bought from",
    Time:"2:24pm",
    Price:"₦15, 500"
},
{
    image:GreenArrow,
    Date:"30 November, 2022",
    ItemName:"Name of product bought",
    StoreName:"Name of Store bought from",
    Time:"2:24pm",
    Price:"₦15, 500"
},
{
    image:RedArrow,
    Date:"30 November, 2022",
    ItemName:"Name of product bought",
    StoreName:"Name of Store bought from",
    Time:"2:24pm",
    Price:"₦15, 500"
},

{
    image:GreenArrow,
    Date:"30 November, 2022",
    ItemName:"Name of product bought",
    StoreName:"Name of Store bought from",
    Time:"2:24pm",
    Price:"₦15, 500"
},
{
    image:RedArrow,
    Date:"30 November, 2022",
    ItemName:"Name of product bought",
    StoreName:"Name of Store bought from",
    Time:"2:24pm",
    Price:"₦15, 500"
},
{
    image:GreenArrow,
    Date:"30 November, 2022",
    ItemName:"Name of product bought",
    StoreName:"Name of Store bought from",
    Time:"2:24pm",
    Price:"₦15, 500"
},


]


export default WalletData